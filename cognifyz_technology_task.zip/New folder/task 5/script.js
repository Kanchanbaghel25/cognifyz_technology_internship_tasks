// script.js

// Fetch a random dog image
function fetchRandomDogImage() {
    fetch('https://dog.ceo/api/breeds/image/random')
        .then(response => response.json()) // Parse the JSON response
        .then(data => {
            // Update the DOM with the fetched image
            const dogImageContainer = document.getElementById('dogImage');
            dogImageContainer.src = data.message; // The image URL is in the 'message' key
        })
        .catch(error => {
            console.error('Error fetching the dog image:', error);
        });
}

// Call the function when the page loads
document.addEventListener('DOMContentLoaded', fetchRandomDogImage);
